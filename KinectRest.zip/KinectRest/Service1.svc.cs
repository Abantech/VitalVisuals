﻿using Microsoft.Kinect;
using System.Linq;
using VitalVisual.Server;

namespace KinectRest
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        static KinectSensor sensor;
        static BodyFrameReader reader;

        static Body[] bodies;

        public Service1()
        {
            if (sensor == null)
            {
                sensor = KinectSensor.GetDefault();
            }

            if (sensor != null)
            {
                if (reader == null)
                {
                    reader = sensor.BodyFrameSource.OpenReader();
                    reader.FrameArrived += BodyFrameArrived;
                    bodies = new Body[reader.BodyFrameSource.BodyCount];
                }

                if (!sensor.IsOpen)
                {
                    sensor.Open();
                }
            }
        }

        public BodySerializer.SkeletonData GetData()
        {
            var users = bodies.Where(b => b != null && b.IsTracked).ToList();

            return users.Populate();
        }

        private void BodyFrameArrived(object sender, BodyFrameArrivedEventArgs e)
        {
            using (var frame = e.FrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    frame.GetAndRefreshBodyData(bodies);
                }
            }
        }
    }
}
